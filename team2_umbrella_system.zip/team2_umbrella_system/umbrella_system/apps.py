from django.apps import AppConfig


class UmbrellaSystemConfig(AppConfig):
    name = 'umbrella_system'
